import React, { useState } from "react";

const BACKEND_URL = "http://localhost:4000/api/chat";

export default function App() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]); // {role, content, meta?}
  const [loading, setLoading] = useState(false);
  const [lastMeta, setLastMeta] = useState(null); // persona, sentiment, escalate, handoffContext

  const sendMessage = async () => {
    if (!input.trim()) return;

    const newUserMsg = { role: "user", content: input };
    const historyWithPersona = messages.map((m) => ({
      role: m.role,
      content: m.content,
      persona: m.meta?.persona,
      fallback: m.meta?.fallback || false
    }));

    setMessages((prev) => [...prev, newUserMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch(BACKEND_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: newUserMsg.content,
          history: historyWithPersona
        })
      });

      const data = await res.json();

      const assistantMsg = {
        role: "assistant",
        content: data.reply,
        meta: {
          persona: data.persona,
          sentiment: data.sentiment,
          escalate: data.escalate,
          handoffContext: data.handoffContext
        }
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setLastMeta(data);
    } catch (err) {
      console.error(err);
      const fallbackMsg = {
        role: "assistant",
        content:
          "Sorry, something went wrong while generating the response. I’ll escalate this to a human agent.",
        meta: { fallback: true }
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "#0f172a",
        color: "#e5e7eb",
        padding: "20px"
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "800px",
          background: "#020617",
          borderRadius: "16px",
          padding: "16px",
          boxShadow: "0 10px 40px rgba(0,0,0,0.4)",
          display: "flex",
          flexDirection: "column",
          gap: "12px"
        }}
      >
        <h2 style={{ margin: 0, fontSize: "20px" }}>
          Persona-Adaptive Support Agent
        </h2>
        <p style={{ margin: 0, fontSize: "12px", color: "#9ca3af" }}>
          How can i help you ?
        </p>

        {/* Chat window */}
        <div
          style={{
            flex: 1,
            minHeight: "300px",
            maxHeight: "450px",
            overflowY: "auto",
            background: "#020617",
            border: "1px solid #1f2937",
            borderRadius: "12px",
            padding: "12px",
            display: "flex",
            flexDirection: "column",
            gap: "8px"
          }}
        >
          {messages.length === 0 && (
            <div style={{ fontSize: "14px", color: "#6b7280" }}>
              Hello there, Greetings{" "}
              {/* <code>My payment failed three times, this is annoying</code> or{" "} */}
              {/* <code>Our Q4 dashboard ROI numbers look off</code>. */}
            </div>
          )}

          {messages.map((m, idx) => (
            <div
              key={idx}
              style={{
                alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                maxWidth: "75%",
                background: m.role === "user" ? "#1d4ed8" : "#111827",
                borderRadius:
                  m.role === "user"
                    ? "16px 16px 4px 16px"
                    : "16px 16px 16px 4px",
                padding: "8px 10px",
                fontSize: "14px",
                whiteSpace: "pre-wrap"
              }}
            >
              {m.content}
              {m.meta && m.meta.persona && (
                <div
                  style={{
                    marginTop: "4px",
                    fontSize: "10px",
                    color: "#9ca3af"
                  }}
                >
                  Persona: {m.meta.persona} | Sentiment: {m.meta.sentiment}{" "}
                  {m.meta.escalate ? " | Escalated" : ""}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Meta panel */}
        {lastMeta && (
          <div
            style={{
              fontSize: "12px",
              background: "#020617",
              borderRadius: "10px",
              padding: "8px",
              border: "1px solid #1f2937"
            }}
          >
            <strong>Last analysis:</strong> Persona = {lastMeta.persona}, Sentiment ={" "}
            {lastMeta.sentiment},{" "}
            {lastMeta.escalate ? "Escalation = YES" : "Escalation = NO"}
          </div>
        )}

        {/* Input box */}
        <div
          style={{
            display: "flex",
            gap: "8px",
            marginTop: "4px"
          }}
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Describe your issue..."
            rows={2}
            style={{
              flex: 1,
              resize: "none",
              borderRadius: "10px",
              border: "1px solid #1f2937",
              background: "#020617",
              color: "#e5e7eb",
              padding: "8px",
              fontSize: "14px",
              outline: "none"
            }}
          />
          <button
            onClick={sendMessage}
            disabled={loading}
            style={{
              borderRadius: "10px",
              border: "none",
              padding: "0 16px",
              fontSize: "14px",
              cursor: "pointer",
              background: loading ? "#4b5563" : "#22c55e",
              color: "#020617",
              fontWeight: 600
            }}
          >
            {loading ? "Thinking..." : "Send"}
          </button>
        </div>
      </div>
    </div>
  );
}
