// intent.js
import { normalizeText } from "./utils.js";

export function detectIntent(message) {
  const text = normalizeText(message);

  if (
    text.includes("human") ||
    text.includes("agent") ||
    text.includes("support executive") ||
    text.includes("real person")
  ) {
    return "connect_human";
  }

  if (
    text.includes("payment") ||
    text.includes("card") ||
    text.includes("transaction") ||
    text.includes("upi")
  ) {
    return "payment_issue";
  }

  if (
    text.includes("login") ||
    text.includes("log in") ||
    text.includes("sign in") ||
    text.includes("password")
  ) {
    return "login_issue";
  }

  if (
    text.includes("dashboard") ||
    text.includes("report") ||
    text.includes("analytics")
  ) {
    return "dashboard_issue";
  }

  if (
    text.includes("api") ||
    text.includes("token") ||
    text.includes("endpoint") ||
    text.includes("authorization")
  ) {
    return "api_issue";
  }

  if (text.includes("refund") || text.includes("cancel")) {
    return "refund_query";
  }

  if (text.includes("delete account") || text.includes("close account")) {
    return "delete_account";
  }

  // fallback
  return "general_query";
}
