// utils.js

// Very simple similarity: count overlapping words between query and article tags/content.
export function scoreArticle(query, article) {
  const qWords = normalizeText(query).split(" ");
  const text = normalizeText(article.title + " " + article.content + " " + article.tags.join(" "));
  const textWordsSet = new Set(text.split(" "));

  let overlap = 0;
  for (const w of qWords) {
    if (textWordsSet.has(w)) overlap++;
  }
  return overlap;
}

export function normalizeText(str) {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
