// persona.js
import { normalizeText } from "./utils.js";

const TECH_KEYWORDS = [
  "api",
  "endpoint",
  "server",
  "stack trace",
  "latency",
  "integration",
  "token",
  "header",
  "request",
  "response",
  "sdk"
];

const BUSINESS_KEYWORDS = [
  "roi",
  "kpi",
  "budget",
  "quarter",
  "q1",
  "q2",
  "q3",
  "q4",
  "revenue",
  "cost",
  "report",
  "dashboard",
  "management"
];

const ANGRY_WORDS = [
  "angry",
  "frustrated",
  "annoyed",
  "irritated",
  "useless",
  "worst",
  "nonsense",
  "idiot",
  "fix it",
  "wtf",
  "hell"
];

// Simple sentiment
export function detectSentiment(message) {
  const text = normalizeText(message);
  let score = 0;
  ANGRY_WORDS.forEach((w) => {
    if (text.includes(w)) score -= 2;
  });

  // crude: presence of "please", "thanks" etc as positive
  if (text.includes("thank")) score += 1;
  if (text.includes("please")) score += 1;

  if (score <= -2) return "very_negative";
  if (score < 0) return "negative";
  if (score === 0) return "neutral";
  return "positive";
}

// Persona detection: Technical Expert, Business Exec, Frustrated User, General User
export function detectPersona(message, history = []) {
  const text = normalizeText(message);
  const sentiment = detectSentiment(message);

  const hasTech = TECH_KEYWORDS.some((w) => text.includes(w));
  const hasBusiness = BUSINESS_KEYWORDS.some((w) => text.includes(w));

  if (sentiment === "very_negative" || text.includes("refund") || text.includes("complaint")) {
    return "Frustrated User";
  }

  if (hasTech) {
    return "Technical Expert";
  }

  if (hasBusiness) {
    return "Business Exec";
  }

  // fallback: if earlier messages marked as persona, reuse
  const lastPersonaMsg = history
    .slice()
    .reverse()
    .find((m) => m.persona);
  if (lastPersonaMsg) return lastPersonaMsg.persona;

  return "General User";
}
