// kb.js

export const KB_ARTICLES = [
  {
    id: "KB_PAYMENT",
    title: "Payment Failure – Card Declined or Failed",
    intents: ["payment_issue", "refund_query"],
    tags: ["payment", "card", "declined", "failed", "transaction", "upi"],
    content: `
If your payment keeps failing:

1. Check that your card has sufficient balance or available credit.
2. Confirm that online / international transactions are enabled with your bank.
3. Make sure card details (number, expiry, CVV) and OTP are entered correctly.
4. Wait 5–10 minutes and try again with a stable network.
5. Avoid multiple rapid retries; banks may temporarily block suspicious attempts.
`
  },

  // 🔐 General login issues
  {
    id: "KB_LOGIN",
    title: "Login Issues – Incorrect Password or Cannot Sign In",
    intents: ["login_issue"],
    tags: [
      "login",
      "log in",
      "sign in",
      "password",
      "incorrect password",
      "wrong password",
      "account login"
    ],
    content: `
If you cannot log in due to incorrect password:

1. Make sure Caps Lock / Num Lock are not interfering with your password.
2. Try typing your password in a notes app to confirm there are no extra spaces.
3. If you still see "incorrect password", click on "Forgot Password".
4. Enter your registered email or phone number.
5. Check your inbox and spam folder for the reset link or OTP.
6. Choose a strong new password and try signing in again.
`
  },

  // 🚫 Specific case: "user not found" error
  {
    id: "KB_LOGIN_USER_NOT_FOUND",
    title: "Login Issue – 'User Not Found' or Account Does Not Exist",
    intents: ["login_issue"],
    tags: [
      "login",
      "user not found",
      "no account",
      "email not registered",
      "account does not exist",
      "sign up first"
    ],
    content: `
If you see a "User not found" or "Account does not exist" message while logging in:

1. Make sure you are using the same email/phone number that you used while signing up.
2. Check for small typos in your email ID (for example .con instead of .com, extra dots, missing letters).
3. If you never created an account with this email, you will need to sign up first instead of logging in.
4. If you are sure you already have an account but still see "user not found", try:
   - Logging in with any alternate email/phone numbers you might have used.
   - Checking any old welcome email from us to confirm your registered ID.
5. If the problem continues, contact support and share a screenshot of the error message along with the email/phone you are using.
`
  },

  {
    id: "KB_API_AUTH",
    title: "API Integration – Authentication and Authorization",
    intents: ["api_issue"],
    tags: ["api", "developer", "integration", "authentication", "token", "header", "401"],
    content: `
To authenticate API requests:

- Send the API key in the Authorization header:
  Authorization: Bearer <YOUR_API_KEY>
- Ensure you are calling the correct base URL and using HTTPS.
- If you receive 401 Unauthorized:
  - Check that the API key is active and not expired.
  - Verify there are no extra spaces or hidden characters.
  - Confirm that your clock/timezone is correct if signed tokens are used.
`
  },
  {
    id: "KB_DASHBOARD",
    title: "Dashboard Data Delay – Analytics Not Updating",
    intents: ["dashboard_issue"],
    tags: ["dashboard", "analytics", "report", "metrics", "delay"],
    content: `
About dashboard refresh:

- Data is refreshed approximately every 15 minutes.
- On high-traffic days, the delay can be up to 30 minutes.
- The underlying campaign performance is not affected, only the visible dashboard.
- If the data has not changed for more than 1 hour, please contact support with a screenshot and time range.
`
  },
  {
    id: "KB_REFUND",
    title: "Refund and Cancellation Policy – Overview",
    intents: ["refund_query"],
    tags: ["refund", "cancellation", "cancel", "policy"],
    content: `
Refund policy (general):

- Full refund if canceled within 24 hours of purchase and before usage.
- Partial refund afterwards, depending on how much of the service has been used.
- Refunds are processed to the original payment method within 5–7 business days.
- For payment failures where money is debited but not reflected, the bank may take 3–5 days to auto-reverse.
`
  },
  {
    id: "KB_DELETE_ACCOUNT",
    title: "Close or Delete Account – Data Removal",
    intents: ["delete_account"],
    tags: ["account", "delete account", "close account", "privacy"],
    content: `
To permanently delete your account:

1. Open Settings > Account.
2. Click on "Delete Account" or "Close Account".
3. Confirm via the OTP sent to your registered email or phone.
4. Your account will be scheduled for deletion and data will be removed within 30 days, except for legally required logs.

After deletion, you will not be able to recover your data or history.
`
  }
];

