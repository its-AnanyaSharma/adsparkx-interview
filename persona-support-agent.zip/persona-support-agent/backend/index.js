// index.js
import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import { KB_ARTICLES } from "./KB.js";
import { scoreArticle } from "./utils.js";
import { detectPersona, detectSentiment } from "./persona.js";
import { shouldEscalate } from "./escalation.js";
import { detectIntent } from "./intent.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
// Tracks which follow-up question we are on for a given intent
function getFollowupStage(history, intent) {
  if (!history || history.length === 0) return 0;

  const lastAssistant = [...history].reverse().find((m) => m.role === "assistant");
  if (!lastAssistant || !lastAssistant.content) return 0;

  // Look for marker like: [FOLLOWUP_FOR_INTENT:login_issue:Q1]
  const match = lastAssistant.content.match(/\[FOLLOWUP_FOR_INTENT:([a-z_]+):Q(\d+)\]/);

  if (match && match[1] === intent) {
    const stage = parseInt(match[2], 10); // 1,2,3...
    return stage; // we already asked Q(stage), next will be Q(stage+1)
  }

  return 0;
}

// ========== SIMPLE KB RETRIEVAL ==========
function retrieveRelevantArticles(query, intent, limit = 1) {
  let candidates = KB_ARTICLES;

  if (intent && intent !== "general_query") {
    const intentMatches = KB_ARTICLES.filter(
      (a) => Array.isArray(a.intents) && a.intents.includes(intent)
    );
    if (intentMatches.length > 0) {
      candidates = intentMatches;
    }
  }

  const scored = candidates
    .map((article) => ({
      article,
      score: scoreArticle(query, article)
    }))
    .sort((a, b) => b.score - a.score);

  if (scored.length === 0) {
    return candidates.slice(0, limit);
  }

  return scored.slice(0, limit).map((s) => s.article);
}


// ========== PERSONA-AWARE RESPONSE GENERATION ==========
function generatePersonaResponse({
  message,
  persona,
  sentiment,
  kbArticles,
  intent,
  escalate,
  escalationLevel,
  followupStage
}) {
  const kbText =
    kbArticles && kbArticles.length > 0
      ? kbArticles.map((a) => `• ${a.title}\n${a.content.trim()}`).join("\n\n")
      : "I couldn't find a matching article in my knowledge base.";

  // ========= FOLLOW-UP QUESTIONS (ONE AT A TIME) =========

  // Define follow-up questions per intent
  const FOLLOWUP_QUESTIONS = {
    login_issue: [
      "Are you seeing an error like 'incorrect password', 'user not found', or something else?",
      "Have you already tried using the 'Forgot Password' option on the login page?",
      "Did you receive any reset email or OTP in your inbox or spam folder?"
    ],
    payment_issue: [
      "Are you paying via card, UPI, or net banking?",
      "Do you see any specific error message on the payment page (for example 'transaction failed' or 'bank declined')?",
      "Has the amount been debited from your bank account or card statement?"
    ],
    api_issue: [
      "Which API endpoint are you calling?",
      "What HTTP status code are you getting (for example 400, 401, 500)?",
      "Are you sending the Authorization header with the Bearer token in your request?"
    ],
    dashboard_issue: [
      "Since when have you noticed that the dashboard is not updating correctly?",
      "Is the issue with all reports or only a specific report/date range?",
      "Have you tried refreshing the page or checking again after 15–20 minutes?"
    ],
    refund_query: [
      "Is this a refund for a failed payment or for a normal cancellation?",
      "When did you make the original payment (approximately)?",
      "Has your bank or card statement already shown any refund entry?"
    ],
    delete_account: [
      "Do you want to temporarily deactivate the account or permanently delete it?",
      "Have you already checked the 'Account' or 'Settings' section in the app or website?",
      "Are you okay with your data being removed permanently after deletion?"
    ]
  };

  const questionsForIntent = FOLLOWUP_QUESTIONS[intent] || null;

  // Escalation always takes priority for serious cases like explicit human/legal
  if (intent === "connect_human" && escalate) {
    if (persona === "Technical Expert") {
      return `
I’ve forwarded your request to our technical support team.

A human agent will review your previous attempts, logs, and this conversation, and get back to you shortly. You won’t need to repeat the details again.
      `.trim();
    }

    if (persona === "Business Exec") {
      return `
I’m escalating this to a dedicated support executive.

They’ll reach out to you shortly with a clear action plan. I’ve already shared your query and context so you don’t have to repeat anything.
      `.trim();
    }

    if (persona === "Frustrated User") {
      return `
I understand this has been frustrating, and I’m really sorry for the trouble.

I’ve forwarded your case to a human support agent who will take over from here. They’ll review this entire conversation and contact you shortly, so you won’t have to explain everything again.
      `.trim();
    }

    // General user
    return `
I’ve forwarded your request to our support team.

A human agent will review this conversation and reach out to you soon.
    `.trim();
  }

  if (escalate && escalationLevel && escalationLevel !== "None") {
    return `
I’m going to escalate this to a human support agent because it needs closer attention (${escalationLevel} priority).

Here’s a quick summary of what I’m passing to them:
- Your message: "${message}"
- Detected persona: ${persona}
- Recent guidance based on our internal docs:
${kbText}

They’ll review this and get back to you as soon as possible.
    `.trim();
  }

  // 🔥 If we have follow-up questions for this intent, ask ONE at a time
  if (questionsForIntent) {
    const totalQ = questionsForIntent.length;

    // followupStage = 0  → ask Q1
    // followupStage = 1  → ask Q2
    // followupStage = 2  → ask Q3
    // followupStage >= totalQ → move to solution
    if (followupStage < totalQ) {
      const nextQIndex = followupStage; // 0-based index
      const questionText = questionsForIntent[nextQIndex];

      let intro = "To help you better, I need a bit more detail.\n\n";

      if (persona === "Frustrated User") {
        intro =
          "I know this is already frustrating, but just one quick question so I can guide you correctly:\n\n";
      } else if (persona === "Technical Expert") {
        intro =
          "Let me narrow this down with one quick technical question:\n\n";
      } else if (persona === "Business Exec") {
        intro =
          "To understand the impact clearly, I need one quick detail:\n\n";
      }

      // Marker helps us know which question was asked last: Q1, Q2, ...
      const marker = `[FOLLOWUP_FOR_INTENT:${intent}:Q${nextQIndex + 1}]`;

      return `${intro}${questionText}\n\n${marker}`;
    }
    // else: we’ve already asked all follow-up questions → now provide solution below
  }

  // ========= NORMAL PERSONA-BASED SOLUTION (AFTER FOLLOW-UPS) =========

  if (persona === "Technical Expert") {
    return `
You seem comfortable with technical details, so I’ll keep this precise.

Here’s what I can infer from your query:
${message}

Relevant internal notes:
${kbText}

If you can share any logs, status codes, or sample requests, it’ll be easier to pinpoint the exact issue.
    `.trim();
  }

  if (persona === "Business Exec") {
    return `
Let me summarise this from a business perspective.

Issue:
${message}

Impact & explanation:
${kbText}

In short, this may be a temporary technical issue, but your core data and campaigns remain safe. If this is blocking reporting or decision-making, we can mark it for escalation.
    `.trim();
  }

  if (persona === "Frustrated User") {
    return `
I'm really sorry you're facing this 🙏 I know it’s frustrating when things don’t work as expected.

Here’s what most often causes this and what usually fixes it:
${kbText}

If you’ve already tried similar steps and it still doesn’t work, tell me what you see on screen and I’ll either refine the steps or escalate this with full context so you don’t have to repeat yourself.
    `.trim();
  }

  return `
Thanks for reaching out!

Here’s what might help with your issue:
${kbText}

If this doesn’t fully solve it, let me know what you tried and what you see on screen, and I’ll guide you further.
  `.trim();
}

// ========== ROUTES ==========

app.get("/", (req, res) => {
  res.send("Persona-adaptive support backend is running.");
});

app.post("/api/chat", (req, res) => {
  const { message, history = [] } = req.body;

  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "message is required" });
  }

  // 1️⃣ Analyse message
  const sentiment = detectSentiment(message);
  const persona = detectPersona(message, history);
  const intent = detectIntent(message);

  // 🔥 NEW: figure out which follow-up step we are on
  const followupStage = getFollowupStage(history, intent); // 0 = none asked yet

  // 2️⃣ Retrieve relevant KB content
  const kbArticles = retrieveRelevantArticles(message, intent, 1);

  // 3️⃣ Decide escalation
  const escalationResult = shouldEscalate({ message, persona, sentiment, history });
  const { escalate, escalationLevel, escalationReason } = escalationResult;

  // 4️⃣ Generate persona + intent aware reply
  const reply = generatePersonaResponse({
    message,
    persona,
    sentiment,
    kbArticles,
    intent,
    escalate,
    escalationLevel,
    followupStage
  });

  // 5️⃣ Build handoff context if escalation needed
  const handoffContext = escalate
    ? {
        persona,
        sentiment,
        intent,
        message,
        kbArticles,
        history,
        escalationLevel,
        escalationReason,
        summary: `User (${persona}, sentiment: ${sentiment}, intent: ${intent}) reported: "${message}".`,
        priority:
          escalationLevel === "Critical" || escalationLevel === "High"
            ? "High"
            : "Normal"
      }
    : null;

  // 6️⃣ Send response to frontend
  res.json({
    reply,
    persona,
    sentiment,
    intent,
    escalate,
    escalationLevel,
    escalationReason,
    handoffContext
  });
});


app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
