// escalation.js

export function shouldEscalate({ message, persona, sentiment, history }) {
  const text = message.toLowerCase();
  let escalationScore = 0;
  let reasons = [];

  // 1️⃣ Explicit human demand (IMMEDIATE CRITICAL ESCALATION)
  if (
    text.includes("human") ||
    text.includes("agent") ||
    text.includes("support executive")
  ) {
    return buildResult("Critical", "User explicitly requested a human agent");
  }

  // 2️⃣ Legal / complaint / refund threats
  if (
    text.includes("complaint") ||
    text.includes("legal") ||
    text.includes("lawsuit") ||
    text.includes("court") ||
    text.includes("consumer forum")
  ) {
    escalationScore += 5;
    reasons.push("Legal or complaint-related risk detected");
  }

  // 3️⃣ Strong negative language
  const aggressiveWords = [
    "worst",
    "useless",
    "fraud",
    "scam",
    "angry",
    "frustrated",
    "ridiculous",
    "terrible",
    "annoyed"
  ];

  aggressiveWords.forEach((w) => {
    if (text.includes(w)) {
      escalationScore += 1;
      reasons.push("Strong negative language detected");
    }
  });

  // 4️⃣ Sentiment-based escalation
  if (sentiment === "very_negative") {
    escalationScore += 3;
    reasons.push("Very negative sentiment detected");
  } else if (sentiment === "negative") {
    escalationScore += 1;
  }

  // 5️⃣ Persona-based priority
  if (persona === "Frustrated User") {
    escalationScore += 2;
    reasons.push("User classified as Frustrated");
  }

  if (persona === "Business Exec") {
    escalationScore += 2;
    reasons.push("High-value business user");
  }

  // 6️⃣ Repeated failure detection
  const botFailures = history.filter(
    (m) => m.role === "assistant" && m.fallback === true
  ).length;

  if (botFailures >= 2) {
    escalationScore += 4;
    reasons.push("Multiple unresolved attempts by bot");
  }

  // 7️⃣ Repetition of same complaint by user
  const repeatedIssue = history.filter(
    (m) => m.role === "user" && m.content === message
  ).length;

  if (repeatedIssue >= 2) {
    escalationScore += 3;
    reasons.push("User repeating the same issue multiple times");
  }

  // ✅ FINAL DECISION BASED ON ESCALATION ZONE
  /**
   * 0–2  → No Escalation
   * 3–5  → Low Priority
   * 6–8  → High Priority
   * 9+   → Critical
   */

  if (escalationScore >= 9) {
    return buildResult("Critical", reasons.join(" | "));
  }

  if (escalationScore >= 6) {
    return buildResult("High", reasons.join(" | "));
  }

  if (escalationScore >= 3) {
    return buildResult("Low", reasons.join(" | "));
  }

  return {
    escalate: false,
    escalationLevel: "None",
    escalationReason: "Issue within automated resolution scope"
  };
}

// Helper function for structured output
function buildResult(level, reason) {
  return {
    escalate: true,
    escalationLevel: level,
    escalationReason: reason
  };
}

